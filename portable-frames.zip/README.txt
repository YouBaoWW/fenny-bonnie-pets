通用桌宠逐帧包：146 张透明 PNG
每张为 192 x 208 RGBA，未缩放、未裁掉透明边缘，像素来自最终精灵表。
读取 portable-manifest.json：characters[].animations 的 frames 依序播放，
每帧 duration_ms 为毫秒；playback 为建议 loop/once。
characters[].look.frames 按 angle_degrees 选取静态视线帧，0度向上、顺时针。
running 为工作/思考；running-left、running-right 才是水平移动。
每套57动作帧+16视线帧，共73帧。保留统一192x208画布，推荐底部中心锚点。
清单包含文件SHA-256、原始RGBA像素哈希和源图坐标；无需账号或API密钥。
完整资料：https://github.com/YouBaoWW/fenny-bonnie-pets/blob/main/PORTING.md
